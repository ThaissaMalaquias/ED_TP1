#ifndef LOAD_H
#define LOAD_H

#include "./ordind.h"

int CarregaArquivo(OrdInd_ptr poi, char * nomeentrada);

#endif